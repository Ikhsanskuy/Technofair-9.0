<div class="row">
  <div class="col-md-12">
    <div class="tile">
      <div class="tile-body">
        <div class="table-responsive">
          <table class="table table-hover table-bordered" id="sampleTable">
            <thead class="bg-light">
              <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Email</th>
                <th>NPM</th>
                <th>Kelas</th>
                <th>Jurusan</th>
                <th>Alamat</th>
                <th>Pilihan Workshop</th>
                <th>Pilihan Pembayaran</th>
                <th>Bukti Pembayaran</th>
                <th>Tanggal</th>
                <th>Opsi</th>
              </tr>
            </thead>
            <tbody>

              <?php 
              $no = 1;
            $query = mysqli_query($con, "SELECT *
                    FROM `data_user`");
            while ($data = mysqli_fetch_array($query)) {
              $nama = $data['nama'];
              $email = $data['email'];
              $npm = $data['npm'];
              $kelas = $data['kelas'];
              $jurusan = $data['jurusan'];
              $alamat = $data['alamat'];
              $pilihan_workshop = $data['pilihan_workshop'];
              $pilihan_pembayaran = $data['pilihan_pembayaran'];
              $bukti_pembayaran = $data['bukti_pembayaran'];
              $date = $data['date'];
            ?>
              <tr>
              <td><?php echo $no++; ?></td>
            <td><?php echo $nama; ?></td>
            <td><?php echo $email; ?></td>
            <td><?php echo $npm; ?></td>
            <td><?php echo $kelas; ?></td>
            <!-- <td><?php echo $nama_m; ?> 
                <br>
                <sub>(<?php echo $email_m; ?>)</sub>
            </td> -->
            <td><?php echo $jurusan; ?></td>
            <td><?php echo $alamat; ?></td>
            <td><?php echo $pilihan_workshop; ?></td>
            <td><?php echo $pilihan_pembayaran; ?></td>
            <td>
                <a href="<?php echo "../../user/assets/bukti_pembayaran/".$bukti_pembayaran; ?>" download>
                    <?php echo $bukti_pembayaran;; ?>
                </a>
            </td>
            <td><?php echo $date; ?></td>
              <!-- <tr>
                <form action="../config/SEND-EMAIL/ws-simpan-ml.php" method="post">
                  <td><?=$no?></td>
                  <td><?=htmlspecialchars(mysqli_real_escape_string($con,$row['nama']));?></td>
                  <td><?=htmlspecialchars(mysqli_real_escape_string($con,$row['email']));?></td>
                  <td><?=htmlspecialchars(mysqli_real_escape_string($con,$row['npm']));?></td>
                  <td><?=htmlspecialchars(mysqli_real_escape_string($con,$row['kelas']));?></td>
                  <td><?=htmlspecialchars(mysqli_real_escape_string($con,$row['jurusan']));?></td>
                  <td><?=htmlspecialchars(mysqli_real_escape_string($con,$row['alamat']));?></td>
                  <td><?=htmlspecialchars(mysqli_real_escape_string($con,$row['pilihan_workshop']));?></td>
                  <td><?=htmlspecialchars(mysqli_real_escape_string($con,$row['pilihan_pembayaran']));?></td>
                  <td>
                    <a href="<?php echo "../../users/assets/bukti_pembayaran/".$data['bukti_pembayaran'] ?>" download>
                      <img src="<?php echo "../../users/assets/bukti_pembayaran/".$data['bukti_pembayaran'] ?>"
                        style="width: 100px; height: 100px;">
                    </a>
                  </td>
                  <td><?=htmlspecialchars(mysqli_real_escape_string($con,$row['date']));?></td>
                </form> -->
                <!-- <td>
                        <a href="ubah.php?id=<?=$row['id']?>"><i class="fas fa-pen"></i></a> | 
                        <a href="hapus.php?id=<?=$row['id']?>" onclick="return confirm('Apakah anda yakin ingin menghapus ini?\n\nData tidak bisa dikembalikan ketika sudah dihapus.');"><i class="fas fa-trash-alt"></i></a>
                      </td> -->
              </tr>
              <?php
                    $no++;
                    };
                    ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>