<?php
include_once "config/koneksi.php";

$id = htmlspecialchars(mysqli_real_escape_string($con,$_GET['id']));

$sql = "DELETE FROM `data_user` WHERE `id` = $id";

$result = mysqli_query($con,$sql);

if (mysqli_affected_rows($con) > 0) {
echo"<script>alert('Data berhasil dihapus !'); location.href='index.php';</script>";
}else{
echo"<script>alert('Data gagal dihapus !');</script>";
}
?>