<?php
session_start();

if(!isset($_SESSION["admin"])){
  header("location: login.php");
}

include_once "config/koneksi.php";

if(isset($_POST['ubah'])){
  $id = htmlspecialchars(mysqli_real_escape_string($con,$_GET['id']));
  $email = htmlspecialchars(mysqli_real_escape_string($con,$_POST['email']));
  $nama = htmlspecialchars(mysqli_real_escape_string($con,$_POST['nama']));
  $npm = htmlspecialchars(mysqli_real_escape_string($con,$_POST['npm']));
  $kelas = htmlspecialchars(mysqli_real_escape_string($con,$_POST['kelas']));
  $jurusan = htmlspecialchars(mysqli_real_escape_string($con,$_POST['jurusan']));
  $alamat  = htmlspecialchars(mysqli_real_escape_string($con,$_POST['alamat']));
  $pilihan_workshop = htmlspecialchars(mysqli_real_escape_string($con,$_POST['pilihan_workshop']));
  $pilihan_pembayaran = htmlspecialchars(mysqli_real_escape_string($con,$_POST['pilihan_pembayaran']));
  
  $nomor_acak = round(microtime(true));
  $foto = $_FILES['bukti_pembayaran']['name'];
  $tipe_foto = $_FILES['bukti_pembayaran']['type'];
  $file_tmp = $_FILES['bukti_pembayaran']['tmp_name'];
  $file_size = $_FILES['bukti_pembayaran']['size'];
  $foto_baru = $nomor_acak. '_' .$foto;

  
  // $nohp = htmlspecialchars(mysqli_real_escape_string($con,$_POST['nohp']));

  $sql = "UPDATE `data_user` SET 
          `nama`='$nama',
          `npm`='$npm',
          `kelas`='$kelas',
          `jurusan`='$jurusan',
          `alamat`='$alamat',
          `pilihan_workshop`='$pilihan_workshop',
          `pilihan_pembayaran`='$pilihan_pembayaran',
          `bukti_pembayaran`='$foto_baru' WHERE `id`='$id'";

  // $result = mysqli_query($con,$sql);
  // if (mysqli_affected_rows($con) > 0) {
  //     echo"<script>alert('Data berhasil diubah !'); location.href='index.php';</script>";
  // }else{
  //     echo"<script>alert('Data gagal diubah !');</script>";
  // }
  if ($sql) {
    if ($file_size < 3000000) {
        if($tipe_foto == "image/jpeg" || $tipe_foto == "image/png" || $tipe_foto == "image/jpg"){
            @move_uploaded_file($file_tmp, "../users/assets/bukti_pembayaran/".$foto_baru);
            echo "Berhasil";
        }else{
            echo"<script>alert('Maaf format file berkas selain JPG/JPEG/PNG tidak di dukung');
            location.href='ubah.php';</script>";
        }
    }else {
        echo "Gagal, ukuran foto harus dibawah 3 mb";
    }
}else {
    echo "Gagal nambah data baru";
}

}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Admin FIKCLASS 2022</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="../assets/img/logo.png" />
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- fontawesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  </head>

  <body class="app sidebar">

    <!-- Navbar-->
    <header class="app-header"><a class="app-header__logo" href="index.html">FIKCLASS 2022</a>
      <!-- Sidebar toggle button--><a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a>
      <!-- Navbar Right Menu-->
      <ul class="app-nav">

        <!-- User Menu-->
        <li class="dropdown"><a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu"><i class="fa fa-user fa-lg"></i></a>
          <ul class="dropdown-menu settings-menu dropdown-menu-right">
            <li><a class="dropdown-item" href="logout.php"><i class="fa fa-sign-out fa-lg"></i> Logout</a></li>
          </ul>
        </li>
      </ul>
    </header>
    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <aside class="app-sidebar">
      <div class="app-sidebar__user bg-warning">
        <div>
          <p class="app-sidebar__user-name">Admin</p>
          <p class="app-sidebar__user-designation">FIKCLASS 2022</p>
        </div>
      </div>
      <ul class="app-menu">
        <li><a class="app-menu__item active" href="index.php"><i class="app-menu__icon fa fa-dashboard"></i><span class="app-menu__label">Dashboard</span></a></li>
      </ul>
    </aside>
    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-th-list"></i> Data Peserta</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb side">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item">Dashboard</li>
        </ul>
      </div>
      <div class="row">
          <div class="col-12">
              <div class="tile">
                  <div class="tile-body">
                      <form action="" method="post" enctype="multipart/form-data">
                          <h3 style="text-align: right; margin:0;">
                              <a href="./index.php" style="text-decoration: none; display:inline;"
                                  class="text-dark"><span class="close-btn">&times;</span></a>
                          </h3>
                          <div class="form-group text-center">
                              <h4>Ubah data peserta<span class="text-warning"> Filing</span> 2022</h4>
                              <br>
                          </div>
                          <?php
                          $id = $_GET['id'];
                          $sql_ubah = "SELECT * FROM  `data_user` WHERE `id` = $id";

                          $result_ubah = mysqli_query($con,$sql_ubah);

                          while($row = mysqli_fetch_assoc($result_ubah)){
                          ?>
                          <div class="row">
                            <input type="hidden" value="<?=$row['id']?>">
                              <div class="col-12 col-md-6">
                                  <label for="nama">Nama</label><br>
                                  <input type="text" class="form-control" id="nama" required name="nama" value="<?=$row['nama']?>"><br>
                              </div>
                              <div class="col-12 col-md-6">
                                  <label for="npm">NPM</label>
                                  <input type="text" class="form-control" id="npm" required name="npm" value="<?=$row['npm']?>"><br>
                              </div>
                              <div class="col-12 col-md-6">
                                  <label for="kelas">Kelas</label>
                                  <input type="text" class="form-control" id="kelas" required name="kelas" value="<?=$row['kelas']?>"><br>
                              </div>
                              <div class="col-12 col-md-6">
                                  <label for="jurusan">Jurusan</label>
                                  <input type="text" class="form-control" id="jurusan" required name="jurusan" value="<?=$row['jurusan']?>"><br>
                              </div>
                              <div class="col-12 col-md-6">
                                  <label for="Alamat">Alamat</label>
                                  <input type="text" class="form-control" id="alamat" required name="alamat" value="<?=$row['alamat']?>"><br>
                              </div>
                              <div class="col-12 col-md-6">
                                  <label for="pilihan_workshop">Pilihan Workshop</label>
                                  <input type="text" class="form-control" id="pilihan_workshop" required name="pilihan_workshop" value="<?=$row['pilihan_workshop']?>"><br>
                              </div>
                              <div class="col-12 col-md-6">
                                  <label for="pilihan_pembayaran">Pilihan Pembayaran</label>
                                  <input type="text" class="form-control" id="pilihan_pembayaran" required name="pilihan_pembayaran" value="<?=$row['pilihan_pembayaran']?>"><br>
                              </div>
                              <div class="col-12 col-md-6">
                                  <label for="bukti_pembayaran">Bukti Pembayaran</label>
                                  <input type="file" class="form-control" id="bukti_pembayaran" required name="bukti_pembayaran" value="<?=$row['bukti_pembayaran']?>"><br>
                              </div>
                              <?php
                              };
                              ?>
                              <div class="col-12 col-md-6">
                                  <button type="submit" name="ubah" class="btn btn-warning btn-lg text-dark">
                                      <h5 class="m-0">ubah</h5>
                                  </button>
                              </div>
                          </div>
                      </form>
                  </div>
              </div>
          </div>
      </div>
    </main>
    <!-- Essential javascripts for application to work-->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="js/plugins/pace.min.js"></script>
    <!-- Page specific javascripts-->
    <!-- Data table plugin-->
    <script type="text/javascript" src="js/plugins/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="js/plugins/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">$('#sampleTable').DataTable();</script>

  </body>
</html>