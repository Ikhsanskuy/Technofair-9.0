<?php
include "../koneksi.php";

$Id_mc = $_GET['Id_mc'];

$queries = mysqli_query($connn, "UPDATE m_competitions SET stats_tf = 2 WHERE Id_mc = '$Id_mc' ");

if($queries){

    echo "<script>alert('Account Rejected'); 
    location.href='../../page/competitions/pubg-competition.php'; </script>";

}else{

    echo "<script>alert('Account Failed To Rejected');
    location.href='../../page/competitions/pubg-competition.php'; </script>";

}