<?php
include "../koneksi.php";

$id = mysqli_real_escape_string($con, $_POST['id']);

if(isset($_POST['reject'])){
    
    $queries = mysqli_query($con, "UPDATE data_user SET stat = 2 WHERE id = $id ");

    echo "<script>alert('Peserta di reject'); 
    location.href='../page/workshop/ml.php'; </script>";

}else{

    echo "<script>alert('Peserta di gagal reject');
    location.href='../page/workshop/ml.php'; </script>";

}